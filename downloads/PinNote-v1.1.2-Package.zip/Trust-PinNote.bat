@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo   PinNote - Trust Certificate Setup
echo ========================================================
echo.
echo Installing PinNote certificate to Trusted Root Authorities...
echo (If Windows asks for Administrator permission, click "Yes")
echo.

powershell -NoProfile -Command "Start-Process certutil -ArgumentList '-addstore -f Root \"%~dp0PinNote-Certificate.cer\"' -Verb RunAs -Wait"

echo.
echo Certificate installed successfully!
echo You can now double-click PinNote-Setup-v1.1.exe to install.
echo.
pause
